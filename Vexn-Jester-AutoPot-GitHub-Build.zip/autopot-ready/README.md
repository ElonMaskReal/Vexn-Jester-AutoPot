# Vexn & Jester AutoPot

Fabric client mod source for Minecraft 1.21.1 (Java 21).

## Build

Run `gradle --no-daemon build` with Gradle 8.8 and Java 21.

The GitHub Actions workflow at `.github/workflows/build.yml` builds the mod on pushes to `main`/`master` and can also be started manually from the Actions tab. Download the `autopot-fabric-1.21.1` artifact from a successful workflow run.

## In-game configuration

Install Fabric API, Cloth Config, and Mod Menu. Open Mod Menu in-game and select AutoPot's config button. The activation key is G by default; it can be changed in Minecraft's Controls settings.
