package dev.axiom.autopot;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import dev.axiom.autopot.screen.AutoPotConfigScreen;

public class AutoPotMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return AutoPotConfigScreen::create;
    }
}
