package dev.axiom.autopot;

import dev.axiom.autopot.config.AutoPotConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.potion.PotionUtil;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class AutoPotMod implements ClientModInitializer {

    public static final String MOD_ID  = "autopot";
    public static final Logger LOGGER  = LoggerFactory.getLogger(MOD_ID);

    // ── keybind ───────────────────────────────────────────────────────────────
    public static KeyBinding activateKey;

    // ── config (written by AutoPotConfig.apply) ───────────────────────────────
    public static float   minHealthHearts  = 4.0f;
    public static int     switchDelayTicks = 0;
    public static int     throwDelayTicks  = 0;
    public static boolean lookDown         = true;
    public static boolean switchBack       = true;
    public static int     requiredPotions  = 2;

    // ── runtime state ─────────────────────────────────────────────────────────
    private boolean          activated    = false;
    private int              potThrown    = 0;
    private int              neededPots   = 2;
    private int              currentSlot  = -1;
    private int              targetSlot   = -1;
    private int              originalSlot = -1;
    private float            origPitch    = 0f;
    private boolean          pitchSaved   = false;
    private int              switchCtr    = 0;
    private int              throwCtr     = 0;
    private List<Integer>    hotbarSlots  = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        activateKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autopot.activate",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.autopot"
        ));

        AutoPotConfig.load();

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        LOGGER.info("[AutoPot] Initialised — 1.21.1");
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Main tick
    // ─────────────────────────────────────────────────────────────────────────
    private void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;

        // keybind edge-detect
        while (activateKey.wasPressed()) {
            tryActivate(mc);
        }

        if (!activated) return;

        // health check — abort if recovered
        if (mc.player.getHealth() > minHealthHearts * 2f) {
            reset(mc);
            return;
        }

        // refresh slot list each tick
        hotbarSlots = findSplashHealthIISlots(mc);
        if (hotbarSlots.size() < neededPots) {
            reset(mc);
            return;
        }

        // look down once
        if (lookDown && !pitchSaved) {
            origPitch  = mc.player.getPitch();
            mc.player.setPitch(90f);
            pitchSaved = true;
        }

        // switch phase
        if (currentSlot != targetSlot) {
            if (switchCtr < switchDelayTicks) { switchCtr++; return; }
            doSlotSwitch(mc, targetSlot);
            currentSlot = targetSlot;
            switchCtr   = 0;
            return;
        }

        // throw phase
        if (potThrown < neededPots) {
            if (throwCtr < throwDelayTicks) { throwCtr++; return; }
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            potThrown++;
            throwCtr = 0;

            if (potThrown < neededPots && potThrown < hotbarSlots.size()) {
                targetSlot  = hotbarSlots.get(potThrown);
                currentSlot = -1;                          // force re-switch
            } else if (potThrown >= neededPots) {
                if (switchBack && originalSlot != -1) doSlotSwitch(mc, originalSlot);
                reset(mc);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Activate
    // ─────────────────────────────────────────────────────────────────────────
    private void tryActivate(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        if (mc.player.getHealth() > minHealthHearts * 2f) return;

        List<Integer> slots = findSplashHealthIISlots(mc);
        if (slots.isEmpty()) return;

        neededPots   = Math.min(requiredPotions, slots.size());
        hotbarSlots  = slots;
        activated    = true;
        potThrown    = 0;
        pitchSaved   = false;
        switchCtr    = 0;
        throwCtr     = 0;
        originalSlot = mc.player.getInventory().selectedSlot;
        currentSlot  = originalSlot;
        targetSlot   = slots.get(0);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────────────────
    private void doSlotSwitch(MinecraftClient mc, int slot) {
        mc.player.getInventory().selectedSlot = slot;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private void reset(MinecraftClient mc) {
        if (lookDown && pitchSaved && mc.player != null) {
            mc.player.setPitch(origPitch);
        }
        activated    = false;
        potThrown    = 0;
        neededPots   = 2;
        currentSlot  = -1;
        targetSlot   = -1;
        pitchSaved   = false;
        switchCtr    = 0;
        throwCtr     = 0;
        hotbarSlots.clear();
    }

    /**
     * Scan hotbar slots 0-8 for Splash Potion of Instant Health II.
     * amplifier >= 1 means level II (0-indexed).
     */
    private List<Integer> findSplashHealthIISlots(MinecraftClient mc) {
        List<Integer> out = new ArrayList<>();
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isEmpty() || stack.getItem() != Items.SPLASH_POTION) continue;
            for (StatusEffectInstance fx : PotionUtil.getPotionEffects(stack)) {
                RegistryEntry<StatusEffect> entry = fx.getEffectType();
                if (entry.value() == StatusEffects.INSTANT_HEALTH.value()
                        && fx.getAmplifier() >= 1) {
                    out.add(i);
                    break;
                }
            }
        }
        return out;
    }
}
