package dev.axiom.autopot.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.axiom.autopot.AutoPotMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.*;

public class AutoPotConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
            FabricLoader.getInstance().getConfigDir().resolve("autopot.json");

    // fields mirror mod statics — GSON populates them
    public float   minHealthHearts  = 4.0f;
    public int     switchDelayTicks = 0;
    public int     throwDelayTicks  = 0;
    public boolean lookDown         = true;
    public boolean switchBack       = true;
    public int     requiredPotions  = 2;

    public static void load() {
        AutoPotConfig cfg;
        if (Files.exists(CONFIG_PATH)) {
            try (Reader r = Files.newBufferedReader(CONFIG_PATH)) {
                cfg = GSON.fromJson(r, AutoPotConfig.class);
                if (cfg == null) cfg = new AutoPotConfig();
            } catch (IOException e) {
                AutoPotMod.LOGGER.error("[AutoPot] Config read failed — using defaults", e);
                cfg = new AutoPotConfig();
            }
        } else {
            cfg = new AutoPotConfig();
            save(cfg);
        }
        apply(cfg);
    }

    public static void save(AutoPotConfig cfg) {
        try (Writer w = Files.newBufferedWriter(CONFIG_PATH)) {
            GSON.toJson(cfg, w);
        } catch (IOException e) {
            AutoPotMod.LOGGER.error("[AutoPot] Config write failed", e);
        }
    }

    private static void apply(AutoPotConfig c) {
        AutoPotMod.minHealthHearts  = c.minHealthHearts;
        AutoPotMod.switchDelayTicks = c.switchDelayTicks;
        AutoPotMod.throwDelayTicks  = c.throwDelayTicks;
        AutoPotMod.lookDown         = c.lookDown;
        AutoPotMod.switchBack       = c.switchBack;
        AutoPotMod.requiredPotions  = c.requiredPotions;
    }
}
