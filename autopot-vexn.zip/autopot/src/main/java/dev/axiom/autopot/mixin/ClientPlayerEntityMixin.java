package dev.axiom.autopot.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Placeholder mixin — required by the mixin config.
 * Extend here if you need to intercept pitch/yaw at packet level
 * or suppress vanilla look-smoothing during the throw sequence.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    // intentionally empty
}
