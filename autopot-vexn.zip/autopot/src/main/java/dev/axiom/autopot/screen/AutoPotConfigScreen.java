package dev.axiom.autopot.screen;

import dev.axiom.autopot.AutoPotMod;
import dev.axiom.autopot.config.AutoPotConfig;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class AutoPotConfigScreen {

    public static Screen create(Screen parent) {

        // ── snapshot current values so the builder knows the defaults ─────────
        AutoPotConfig snap = new AutoPotConfig();
        snap.minHealthHearts  = AutoPotMod.minHealthHearts;
        snap.switchDelayTicks = AutoPotMod.switchDelayTicks;
        snap.throwDelayTicks  = AutoPotMod.throwDelayTicks;
        snap.lookDown         = AutoPotMod.lookDown;
        snap.switchBack       = AutoPotMod.switchBack;
        snap.requiredPotions  = AutoPotMod.requiredPotions;

        // ── builder ───────────────────────────────────────────────────────────
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Text.literal("AutoPot Configuration"))
                .setSavingRunnable(() -> {
                    // values are written back into AutoPotMod statics by each
                    // entry's setSaveConsumer — just persist to disk here
                    AutoPotConfig live = new AutoPotConfig();
                    live.minHealthHearts  = AutoPotMod.minHealthHearts;
                    live.switchDelayTicks = AutoPotMod.switchDelayTicks;
                    live.throwDelayTicks  = AutoPotMod.throwDelayTicks;
                    live.lookDown         = AutoPotMod.lookDown;
                    live.switchBack       = AutoPotMod.switchBack;
                    live.requiredPotions  = AutoPotMod.requiredPotions;
                    AutoPotConfig.save(live);
                });

        ConfigEntryBuilder eb = builder.entryBuilder();

        // ── General category ──────────────────────────────────────────────────
        ConfigCategory general = builder.getOrCreateCategory(Text.literal("General"));

        // Min health threshold (hearts, float 0.5 – 10)
        general.addEntry(eb
                .startFloatField(
                        Text.literal("Min Health (hearts)"),
                        snap.minHealthHearts)
                .setDefaultValue(4.0f)
                .setMin(0.5f)
                .setMax(10.0f)
                .setTooltip(Text.literal("Trigger AutoPot when HP drops below this many hearts."))
                .setSaveConsumer(v -> AutoPotMod.minHealthHearts = v)
                .build());

        // Required potions (1 – 9)
        general.addEntry(eb
                .startIntField(
                        Text.literal("Potions to Throw"),
                        snap.requiredPotions)
                .setDefaultValue(2)
                .setMin(1)
                .setMax(9)
                .setTooltip(Text.literal("How many Splash Health II potions to throw per activation."))
                .setSaveConsumer(v -> AutoPotMod.requiredPotions = v)
                .build());

        // Look down before throwing
        general.addEntry(eb
                .startBooleanToggle(
                        Text.literal("Look Down Before Throw"),
                        snap.lookDown)
                .setDefaultValue(true)
                .setTooltip(Text.literal("Pitch camera to 90° so the potion lands at your feet."))
                .setSaveConsumer(v -> AutoPotMod.lookDown = v)
                .build());

        // Switch back to original slot after throwing
        general.addEntry(eb
                .startBooleanToggle(
                        Text.literal("Switch Back After Throw"),
                        snap.switchBack)
                .setDefaultValue(true)
                .setTooltip(Text.literal("Return to your original hotbar slot once all potions are thrown."))
                .setSaveConsumer(v -> AutoPotMod.switchBack = v)
                .build());

        // ── Timing category ───────────────────────────────────────────────────
        ConfigCategory timing = builder.getOrCreateCategory(Text.literal("Timing"));

        // Slot switch delay
        timing.addEntry(eb
                .startIntSlider(
                        Text.literal("Slot Switch Delay (ticks)"),
                        snap.switchDelayTicks,
                        0, 20)
                .setDefaultValue(0)
                .setTooltip(Text.literal("Ticks to wait after switching hotbar slot before throwing. 0 = instant."))
                .setSaveConsumer(v -> AutoPotMod.switchDelayTicks = v)
                .build());

        // Throw delay
        timing.addEntry(eb
                .startIntSlider(
                        Text.literal("Throw Delay (ticks)"),
                        snap.throwDelayTicks,
                        0, 20)
                .setDefaultValue(0)
                .setTooltip(Text.literal("Ticks to wait between consecutive potion throws. 0 = instant."))
                .setSaveConsumer(v -> AutoPotMod.throwDelayTicks = v)
                .build());

        return builder.build();
    }
}
